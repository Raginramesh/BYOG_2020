﻿namespace Bolt
{
	public struct EmptyEventArgs { }
}
